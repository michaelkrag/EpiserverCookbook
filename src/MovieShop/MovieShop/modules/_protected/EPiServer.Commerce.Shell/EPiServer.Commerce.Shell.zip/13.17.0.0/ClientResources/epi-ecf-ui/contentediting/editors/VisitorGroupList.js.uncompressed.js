﻿define("epi-ecf-ui/contentediting/editors/VisitorGroupList", [
// dojo
    "dojo/_base/declare",
// dijit
    "dijit/_WidgetBase",
// dgrid
    "dgrid/Keyboard",
    "dgrid/Grid",
    "dgrid/Selection",
    "dgrid/selector",
    "dgrid/extensions/DijitRegistry",
// epi
    "epi/shell/dgrid/Formatter",
// epi-ecf-ui
    "../../dgrid/_NoDataMessageMixin",
// resources
    "epi/i18n!epi/nls/commerce.widget.visitorgroupselector"
], function(
// dojo
    declare,
// dijit
    _WidgetBase,
// dgrid
    Keyboard,
    Grid,
    Selection,
    selector,
    DijitRegistry,
// epi
    Formatter,
// epi-ecf-ui
    _NoDataMessageMixin,
// resources
    resources
){
    return declare([_WidgetBase], {

        // _store: [private] Object
        //      just a dummy store object to be able to use the selector column mixin
        _store: { getIdentity: function(object){ return object.id; }},

        _gridClass: declare([Grid, Formatter, Selection, Keyboard, DijitRegistry, _NoDataMessageMixin]),

        buildRendering: function () {
            this.inherited(arguments);
            this.grid = this.grid || this._createGrid();
            this.own(this.grid);
        },

        _createGrid: function () {
            var columns = this._getColumns();
            var grid = new this._gridClass({
                "class": "epi-plain-grid epi-grid-height--auto",
                store: this._store,
                columns: columns,
                noDataMessage: resources.novisitorgroups,
                tabableHeader: false,
                selectionMode: "toggle",
                deselectOnRefresh: false
            }, this.domNode);
            return grid;
        },

        _getColumns: function () {
            return {
                checkbox: selector({
                    label: "",
                    selectorType: "checkbox",
                    className: "epi-columnVeryNarrow",
                    sortable: false
                }),
                name: {
                    label: resources.visitorgroups,
                    sortable: false
                }
            };
        },

        getSelectedVisitorGroupIds: function () {
            // summary:
            //      Gets all selected visitorGroups in the list.
            // tags:
            //      public

            return Object.keys(this.grid.selection);
        },

        setSelection: function(selection){
            this.grid.clearSelection();
            if (!selection){
                return;
            }
            selection.forEach(this.grid.select, this.grid);
        },

        _setVisitorGroupsAttr: function(value){
            this.grid.refresh();
            this.grid.renderArray(value);
        }

    });
});