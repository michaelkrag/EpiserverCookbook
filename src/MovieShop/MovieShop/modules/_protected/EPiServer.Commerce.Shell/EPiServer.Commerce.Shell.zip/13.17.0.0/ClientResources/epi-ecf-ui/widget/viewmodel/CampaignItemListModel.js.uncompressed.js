﻿define("epi-ecf-ui/widget/viewmodel/CampaignItemListModel", [
    // dojo
    "dojo/_base/connect",
    "dojo/_base/declare",
    "dojo/_base/json",
    "dojo/_base/lang",
    "dojo/Evented",
    // dijit
    "dijit/Destroyable",
    // epi-cms
    "epi",
    "epi/dependency",
    "epi/shell/command/_Command",
    "epi/shell/selection",
    "epi-cms/component/command/ChangeContext",
    "epi-cms/command/CopyContent",
    "epi-cms/command/CutContent",
    "epi-cms/command/NewContent",
    "epi-cms/command/PasteContent",
    "epi-cms/core/ContentReference",
    "epi-cms/widget/ContentForestStoreModel",
    // epi-ecf-ui
    "../../MarketingUtils",
    "../DeleteCampaignItemDialog",
    "./_MarketingListBaseModel",
    // resources
    "epi/i18n!epi/nls/commerce.widget.marketingitemlist",
    "epi/i18n!epi/nls/episerver.shared"
], function (
    // dojo
    connect,
    declare,
    json,
    lang,
    Evented,
    // dijit
    Destroyable,
    // epi-cms
    epi,
    dependency,
    _Command,
    Selection,
    ChangeContext,
    CopyContent,
    CutContent,
    NewContent,
    PasteContent,
    ContentReference,
    ContentForestStoreModel,
    // epi-ecf-ui
    MarketingUtils,
    DeleteCampaignItemDialog,
    _MarketingListBaseModel,
    // resources
    resources,
    sharedResources
) {
        return declare([_MarketingListBaseModel, Destroyable, Evented], {

            postscript: function () {
                // make sure clipboard is shared across widgets
                this.clipboardManager = this.clipboardManager || dependency.resolve("epi.commerce.global").get("epi.commerce.global.clipboard");

                this.selection = this.selection || new Selection();

                var registry = dependency.resolve("epi.storeregistry");
                this._marketingStatisticsStore = registry.get("epi.commerce.marketingstatistics");
                this._promotionDataStore = registry.get("epi.commerce.promotions");

                var contentRepositoryDescriptors = dependency.resolve("epi.cms.contentRepositoryDescriptors");
                this._campaignTreeStoreModel = new ContentForestStoreModel();
                this._campaignTreeStoreModel.roots = contentRepositoryDescriptors.marketing.roots;
                this.own(
                    this._campaignTreeStoreModel,
                    connect.connect(this._campaignTreeStoreModel, "onSelect", function (itemId, setFocus, onComplete) {
                        this._campaignTreeStoreModel.store.get(itemId).then(function (promotionContent) {
                            promotionContent.properties.schedule.campaignLink = promotionContent.parentLink;
                            var patchedPromotion = {
                                "id": itemId,
                                "properties": {
                                    isActive: 0,
                                    schedule: json.toJson(promotionContent.properties.schedule)
                                }
                            };
                            this._promotionDataStore.patch({ promotions: [patchedPromotion] }, {}).then(function () {
                                this.emit("pasteComplete", itemId);
                            }.bind(this));
                        }.bind(this));
                    }.bind(this))
                );

                this.inherited(arguments);
                this._setupCommands();
            },

            getRedemptions: function (promotionLinks) {
                // summary:
                //      Get redemption number for entire promotions under the given campaign.
                // promotionLinks: [Array]
                //      Collection of promotion link.
                // tags:
                //      public

                var query = {
                    query: "getRedemptions",
                    contentLinks: promotionLinks
                };

                return this._marketingStatisticsStore.query(query);
            },

            getOrderCounts: function (contentLinks) {
                // summary:
                //      Gets total order count for the given campaigns/promotions.
                // contentLinks: [Array]
                //      Collection of campaign/promotion link.
                // tags:
                //      public

                var query = {
                    query: "getOrderCounts",
                    contentLinks: contentLinks
                };

                return this._marketingStatisticsStore.query(query);
            },

            moveItem: function (item, refItem) {
                // summary:
                //      Move promotion to the given campaign.
                // item: [object]
                //      A promotion data object.
                // refItem: [object]
                //      A promotion/campaign data object.
                // tags:
                //      public

                if (epi.isEmpty(refItem) || item.parentLink === refItem.parentLink) {
                    this.emit("updateSelection");
                    return;
                }

                if (MarketingUtils.isSalesCampaign(refItem.typeIdentifier)) {
                    this._campaignTreeStoreModel.move([{ data: item }], refItem);
                } else {
                    this._campaignTreeStoreModel.getAncestors(refItem, function (results) {
                        this._campaignTreeStoreModel.move([{ data: item }], results.reverse()[0]);
                    }.bind(this));
                }
            },
            
            updateCommandModel: function (model) {
                // tags:
                //      extensions

                // Because of the function in base class - "epi/shell/command/_CommandProviderMixin"
                // only set the given object as the command's model.
                // But in this case: CopyContent, CutContent and PasteContent commands required a store as its model.
                // So that, we needed to override this function to pass the desired store object to above commands.
                this._updateCommandModel(model);
                this.updateSelection([model]);
                this._setCommandsAvailibility(model);
            },

            updateSelection: function (selectionData) {
                if (!(selectionData instanceof Array) || selectionData.length === 0) {
                    return;
                }

                var selection = selectionData.map(function (item) {
                    var model = this.get("model"),
                        contextIdWithoutVersion = model ? new ContentReference(model.contextId).createVersionUnspecificReference().toString() : null;
                    return { type: "epi.cms.contentdata", data: item, contextId: contextIdWithoutVersion };
                }, this);

                if (this.selection) {
                    this.selection.set("data", selection);
                }
            },

            createDeleteCommand: function (useContextMenu) {
                var deleteCommand = new _Command({
                    store: this.store,
                    iconClass: "epi-iconClose",
                    label: sharedResources.action.deletelabel,
                    canExecute: false,
                    _onModelChange: function () {
                        this.set("canExecute", !!this.get("model"));
                    },
                    _execute: function () {
                        var dialog = new DeleteCampaignItemDialog({
                            contentData: this.get("model"),
                            store: this.store
                        });
                        dialog.show();
                    }
                });

                if (useContextMenu) {
                    deleteCommand.set("category", "context");
                }

                return deleteCommand;
            },

            _setupCommands: function () {
                // Reset commands list.
                this.commands.length = 0;

                var selectionCommandSettings = {
                    category: "context",
                    clipboard: this.clipboardManager,
                    model: this._campaignTreeStoreModel,
                    selection: this.selection
                };

                // Add specific command for a campaign item
                this.commands.push(new PasteContent(selectionCommandSettings));

                this.commands.push(new ChangeContext({
                    category: "context",
                    forceContextChange: true
                }));

                // Add specific commands for a promotion item
                this.commands.push(new CopyContent(selectionCommandSettings));
                this.commands.push(new CutContent(selectionCommandSettings));

                this.commands.push(new NewContent({
                    category: "context",
                    contentType: MarketingUtils.contentTypeIdentifier.promotionData,
                    label: resources.createpromotion
                }));

                this.commands.push(this.createDeleteCommand(true));
            },

            _updateCommandModel: function (model) {
                this.commands.forEach(function (command) {
                    var isSelectionCommand = command instanceof CopyContent || command instanceof CutContent || command instanceof PasteContent;
                    if (!isSelectionCommand) {
                        command.set("model", model);
                    }
                }, this);
            },

            _setCommandsAvailibility: function (model) {
                this.commands.forEach(function (command) {
                    var isAvailable = true;

                    if (command instanceof PasteContent) {
                        var clipboardData = command.clipboard.data instanceof Array && command.clipboard.data[0] && command.clipboard.data[0].data,
                            clipboardContentLink = clipboardData && clipboardData.contentLink,
                            clipboardContentParentLink = clipboardData && clipboardData.parentLink,
                            deletedItem = this.get("deletedItemId"),
                            isDeleted = deletedItem === clipboardContentLink || deletedItem === clipboardContentParentLink;
                        isAvailable = MarketingUtils.isSalesCampaign(model.typeIdentifier) && !!clipboardContentLink && !isDeleted;
                        command.set("isAvailable", isAvailable);
                    }

                    if (command instanceof CopyContent || command instanceof CutContent) {
                        isAvailable = MarketingUtils.isPromotionData(model.typeIdentifier);
                        command.set("isAvailable", isAvailable);
                    }
                }, this);
            }
        });
    });