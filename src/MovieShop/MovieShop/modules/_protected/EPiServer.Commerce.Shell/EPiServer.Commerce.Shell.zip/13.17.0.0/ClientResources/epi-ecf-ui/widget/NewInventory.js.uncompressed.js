﻿define("epi-ecf-ui/widget/NewInventory", [
    "dojo/_base/array",
    "dojo/_base/declare",
    "epi/shell/widget/FormContainer",
    "../contentediting/editors/_KeyboardBlurMixin",
    "epi/i18n!epi/cms/nls/commerce.widget.inventorycollection.properties"
], function (
    array,
    declare,
    FormContainer,
    _KeyboardBlurMixin,
    resources
){
    return declare([FormContainer, _KeyboardBlurMixin], {
        resources: resources,

        _setMetadataAttr: function (value) {
            // summary:
            //      Sets metadata for this widget.

            array.some(value.properties, function (property) {
                if (property.name === "WarehouseCode") {
                    property.settings.label = resources.warehousecode.label;
                    property.settings.missingMessage = resources.warehousecode.missingmessage;
                    property.settings.readOnly = false; // Make the code field writable.  
                    return true;
                }
            });

            this.metadata = value;
        }
    });
});