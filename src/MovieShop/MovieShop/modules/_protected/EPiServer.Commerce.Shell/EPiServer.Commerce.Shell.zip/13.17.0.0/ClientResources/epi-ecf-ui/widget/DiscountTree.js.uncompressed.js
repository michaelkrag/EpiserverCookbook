﻿define("epi-ecf-ui/widget/DiscountTree", [
// dojo 
    "dojo/_base/array",
    "dojo/_base/declare",
    "dojo/on",
    "dojo/promise/all",
// dijit
    "dijit/Tree",
// epi
    "epi/string",
// epi-ecf-ui
    "./_DiscountTreeNode",
    "./viewmodel/DiscountTreeStoreModel"
],

function (
// dojo    
    array,
    declare,
    on,
    all,
// dijit
    Tree,
// epi
    epiString,
// epi-ecf-ui
    _DiscountTreeNode,
    DiscountTreeStoreModel
) {

    return declare([Tree], {
        // summary:
        //      Represents the tree which display all promotions available, and provides the ability of selecting multiple campaigns and discounts.
        // tags:
        //      internal

        // visibleCampaignNodes [protected] TreeNode Array
        //     Represents visible campaign nodes
        visibleCampaignNodes: null,

        postMixInProperties: function () {
            this.inherited(arguments);

            this.model = this.model || new DiscountTreeStoreModel({
                root: this.root,
                store: this.store
            });

            this.persist = false;

            // Disabling multiselect in tree
            this.dndController.singular = true;
        },

        _onEndKey: function () {
            var lastCampaign = this.visibleCampaignNodes[this.visibleCampaignNodes.length - 1];
            if (lastCampaign) {
                // Focus on the last collapsed campaign
                if (!lastCampaign.isExpanded) {
                    this.focusNode(lastCampaign);
                    return;
                }

                // Focus on the last promotion
                var visiblePromotions = array.filter(lastCampaign.getChildren(), function (promotion) {
                    return !promotion.item.hidden;
                });
                var lastPromotion = visiblePromotions[visiblePromotions.length - 1];
                if (lastPromotion) {
                    this.focusNode(lastPromotion);
                }
            }
        },

        _onDownArrow: function (/*Object*/ message) {
            // summary:
            //		down arrow pressed; get next visible node, set focus there
            var node = message.node,
                nextNode = null;

            do {
                if (node.isExpandable && node.isExpanded && node.hasChildren()) {
                    nextNode = node.getChildren()[0];
                } else {
                    nextNode = node.getNextSibling() || node.getParent().getNextSibling();
                }

                node = nextNode;
            } while (node && node.item.hidden);

            if (node && node.isTreeNode) {
                this.focusNode(node);
            }
        },

        _onUpArrow: function (/*Object*/ message) {
            // summary:
            //		Up arrow pressed; move to previous visible node

            var node = message.node,
                previousSibling = null;

            do {
                previousSibling = node.getPreviousSibling();

                if (previousSibling) {
                    node = previousSibling;
                    // if the previous node is expanded, dive in deep
                    if (node.isExpandable && node.isExpanded && node.hasChildren()) {
                        // move to the last child
                        var children = node.getChildren();
                        node = children[children.length - 1];
                    }
                } else {
                    // if this is the first child, return the parent
                    // unless the parent is the root of a tree with a hidden root
                    var parent = node.getParent();
                    if (this.showRoot || parent !== this.rootNode) {
                        node = parent;
                    }
                }
            } while (node && node.isTreeNode && node.item.hidden);

            if (node && node.isTreeNode) {
                this.focusNode(node);
            }
        },

        _setSearchTextAttr: function (value) {
            this.dndController.selectNone();

            if (!this.rootNode) {
                return;
            }

            if (epiString.isNullOrEmpty(value)) {
                all(array.map(this.rootNode.getChildren(), function (campaignNode) {
                    return campaignNode.collapse();
                })).then(function() {
                    this.model.set("searchText", value);
                    // always emit search found when the search text is null or empty
                    this.emit("filter", { searchFound: true });
                }.bind(this));
            } else {
                this.model.set("searchText", value);
                this.expandAll().then(function () {
                    var visibleCampaigns = this.model.get("visibleCampaigns");
                    this.visibleCampaignNodes = array.map(visibleCampaigns, function (campaign) {
                        return this.getNodesByItem(campaign)[0];
                    }, this);

                    this._selectFirstPromotionNode(this.visibleCampaignNodes);
                    this.emit("filter", { searchFound: visibleCampaigns.length > 0 });
                }.bind(this));
            }
        },

        _selectFirstPromotionNode: function (visibleCampaigns) {
            var self = this;
            visibleCampaigns.some(function (campaignNode) {
                return campaignNode.getChildren().some(function (discountNode) {
                    if (!discountNode.item.hidden) {
                        self.set("firstPromotionNode", discountNode);
                        self.set("selectedNode", discountNode);
                        return true;
                    }
                });
            });
        },

        _onNodeSelectChanged: function (node) {
            var rootNode = this.rootNode;

            if (node === rootNode) {
                this.model.set("checkedItems", node.get("checked") ? [node.item] : []);
                return;
            }

            var checkedItems = [];

            array.forEach(rootNode.getChildren(), function (campaignNode) {
                if (campaignNode.get("checked")) {
                    checkedItems.push(campaignNode.item);
                } else {
                    array.forEach(campaignNode.getChildren(), function (discountNode) {
                        if (discountNode.get("checked")) {
                            checkedItems.push(discountNode.item);
                        }
                    });
                }
            });

            this.model.set("checkedItems", checkedItems);
        },

        _setCheckedItemsAttr: function (value) {
            this.model.set("checkedItems", value);
        },

        _getCheckedItemsAttr: function () {
            return this.model.get("checkedItems");
        },
        
        _createTreeNode: function (/*Object*/args) {
            // summary:
            //      Overridable function to create tree node.
            // args: Object
            //      Tree node creation arguments
            // tags:
            //      extension

            var node = new _DiscountTreeNode(args);
            this.own(node, node.on("nodeSelectChanged", function () {
                this._onNodeSelectChanged(node);
            }.bind(this)));

            return node;
        }
    });

});