﻿define("epi-ecf-ui/contentediting/editors/PackageEntryCollectionEditor", [
    // dojo
    "dojo/_base/declare",
    "dojo/topic",

    // ecf-ui
    "../ModelSupport",
    "../viewmodel/EntryRelationCollectionEditorModel",
    "./LinkEditEditor",
    "./_BaseEntryCollectionEditorGrid",
    "./_GroupDefinitionEditorMixin",

    // Resources
    "epi/i18n!epi/cms/nls/commerce.contentediting.editors.packageentrycollectioneditor"
],
function (
    //dojo
    declare,
    topic,

    // ecf-ui
    ModelSupport,
    EntryRelationCollectionEditorModel,
    LinkEditEditor,
    _BaseEntryCollectionEditorGrid,
    _GroupDefinitionEditorMixin,

    // Resources
    resources
) {
    var collectionEditor = declare([_BaseEntryCollectionEditorGrid], {

        resources: resources,

        modelType: EntryRelationCollectionEditorModel,

        allowedDndTypes: [ModelSupport.contentTypeIdentifier.variationContent, ModelSupport.contentTypeIdentifier.packageContent, ModelSupport.linkTypeIdentifier.relation],

        itemEditorTypes: [ModelSupport.contentTypeIdentifier.variationContent, ModelSupport.contentTypeIdentifier.packageContent],

        relationType: ModelSupport.relationType.packageEntry,

        deleteConfirmationTitle: resources.deleteconfirmation.title,

        deleteConfirmationDescription: resources.deleteconfirmation.description

    });

    return declare([LinkEditEditor, _GroupDefinitionEditorMixin], {

        resources: resources,

        gridCollectionType: collectionEditor
    });
});
